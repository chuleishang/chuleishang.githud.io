#include "array_store.h"

#include <stdlib.h>
#include <string.h>

void array_init(RecordArray *a) {
    a->items = NULL;
    a->size = 0;
    a->capacity = 0;
}

void array_free(RecordArray *a) {
    free(a->items);
    a->items = NULL;
    a->size = 0;
    a->capacity = 0;
}

int array_push(RecordArray *a, Record rec) {
    if (a->size == a->capacity) {
        int new_cap = a->capacity == 0 ? 128 : a->capacity * 2;
        Record *p = (Record *)realloc(a->items, sizeof(Record) * new_cap);
        if (!p) return 0;
        a->items = p;
        a->capacity = new_cap;
    }
    a->items[a->size++] = rec;
    return 1;
}

Record *array_find(RecordArray *a, const char *student_id, const char *course_id) {
    int i;
    for (i = 0; i < a->size; ++i) {
        if (strcmp(a->items[i].student_id, student_id) == 0 &&
            strcmp(a->items[i].course_id, course_id) == 0) {
            return &a->items[i];
        }
    }
    return NULL;
}

int array_remove_key(RecordArray *a, const char *student_id, const char *course_id) {
    int i;
    for (i = 0; i < a->size; ++i) {
        if (strcmp(a->items[i].student_id, student_id) == 0 &&
            strcmp(a->items[i].course_id, course_id) == 0) {
            a->items[i] = a->items[a->size - 1];
            a->size--;
            return 1;
        }
    }
    return 0;
}
