#ifndef ARRAY_STORE_H
#define ARRAY_STORE_H

#include "record.h"

typedef struct {
    Record *items;
    int size;
    int capacity;
} RecordArray;

void array_init(RecordArray *a);
void array_free(RecordArray *a);
int array_push(RecordArray *a, Record rec);
Record *array_find(RecordArray *a, const char *student_id, const char *course_id);
int array_remove_key(RecordArray *a, const char *student_id, const char *course_id);

#endif
