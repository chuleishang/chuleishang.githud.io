#include "avl.h"

#include <stdlib.h>

static int height(AVLNode *n) {
    return n ? n->height : 0;
}

static int max_int(int a, int b) {
    return a > b ? a : b;
}

static AVLNode *new_avl_node(Record rec) {
    AVLNode *node = (AVLNode *)malloc(sizeof(AVLNode));
    if (!node) return NULL;
    node->data = rec;
    node->height = 1;
    node->left = node->right = NULL;
    return node;
}

static AVLNode *rotate_right(AVLNode *y) {
    AVLNode *x = y->left;
    AVLNode *t2 = x->right;
    x->right = y;
    y->left = t2;
    y->height = max_int(height(y->left), height(y->right)) + 1;
    x->height = max_int(height(x->left), height(x->right)) + 1;
    return x;
}

static AVLNode *rotate_left(AVLNode *x) {
    AVLNode *y = x->right;
    AVLNode *t2 = y->left;
    y->left = x;
    x->right = t2;
    x->height = max_int(height(x->left), height(x->right)) + 1;
    y->height = max_int(height(y->left), height(y->right)) + 1;
    return y;
}

static int balance_factor(AVLNode *n) {
    return n ? height(n->left) - height(n->right) : 0;
}

AVLNode *avl_insert_node(AVLNode *node, Record rec, int *ok) {
    int cmp;
    if (!node) {
        *ok = 1;
        return new_avl_node(rec);
    }
    cmp = record_key_cmp(&rec, &node->data);
    if (cmp < 0) node->left = avl_insert_node(node->left, rec, ok);
    else if (cmp > 0) node->right = avl_insert_node(node->right, rec, ok);
    else {
        node->data = rec;
        *ok = 1;
        return node;
    }

    node->height = 1 + max_int(height(node->left), height(node->right));
    if (balance_factor(node) > 1 && record_key_cmp(&rec, &node->left->data) < 0) return rotate_right(node);
    if (balance_factor(node) < -1 && record_key_cmp(&rec, &node->right->data) > 0) return rotate_left(node);
    if (balance_factor(node) > 1 && record_key_cmp(&rec, &node->left->data) > 0) {
        node->left = rotate_left(node->left);
        return rotate_right(node);
    }
    if (balance_factor(node) < -1 && record_key_cmp(&rec, &node->right->data) < 0) {
        node->right = rotate_right(node->right);
        return rotate_left(node);
    }
    return node;
}

static AVLNode *min_value_node(AVLNode *node) {
    AVLNode *cur = node;
    while (cur && cur->left) cur = cur->left;
    return cur;
}

AVLNode *avl_delete_node(AVLNode *root, const char *student_id, const char *course_id, int *deleted) {
    int cmp;
    if (!root) return NULL;
    cmp = key_cmp(student_id, course_id, &root->data);
    if (cmp < 0) root->left = avl_delete_node(root->left, student_id, course_id, deleted);
    else if (cmp > 0) root->right = avl_delete_node(root->right, student_id, course_id, deleted);
    else {
        AVLNode *temp;
        *deleted = 1;
        if (!root->left || !root->right) {
            temp = root->left ? root->left : root->right;
            if (!temp) {
                free(root);
                return NULL;
            }
            *root = *temp;
            free(temp);
        } else {
            temp = min_value_node(root->right);
            root->data = temp->data;
            root->right = avl_delete_node(root->right, temp->data.student_id, temp->data.course_id, deleted);
        }
    }
    root->height = 1 + max_int(height(root->left), height(root->right));
    if (balance_factor(root) > 1 && balance_factor(root->left) >= 0) return rotate_right(root);
    if (balance_factor(root) > 1 && balance_factor(root->left) < 0) {
        root->left = rotate_left(root->left);
        return rotate_right(root);
    }
    if (balance_factor(root) < -1 && balance_factor(root->right) <= 0) return rotate_left(root);
    if (balance_factor(root) < -1 && balance_factor(root->right) > 0) {
        root->right = rotate_right(root->right);
        return rotate_left(root);
    }
    return root;
}

Record *avl_find(AVLNode *root, const char *student_id, const char *course_id) {
    int cmp;
    while (root) {
        cmp = key_cmp(student_id, course_id, &root->data);
        if (cmp == 0) return &root->data;
        root = cmp < 0 ? root->left : root->right;
    }
    return NULL;
}

void avl_clear(AVLNode *root) {
    if (!root) return;
    avl_clear(root->left);
    avl_clear(root->right);
    free(root);
}

int avl_traverse(AVLNode *root, VisitFn visit, void *ctx) {
    if (!root) return 1;
    if (!avl_traverse(root->left, visit, ctx)) return 0;
    if (!visit(&root->data, ctx)) return 0;
    return avl_traverse(root->right, visit, ctx);
}
