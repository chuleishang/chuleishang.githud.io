#ifndef AVL_H
#define AVL_H

#include "record.h"

typedef struct AVLNode {
    Record data;
    int height;
    struct AVLNode *left;
    struct AVLNode *right;
} AVLNode;

AVLNode *avl_insert_node(AVLNode *node, Record rec, int *ok);
AVLNode *avl_delete_node(AVLNode *root, const char *student_id, const char *course_id, int *deleted);
Record *avl_find(AVLNode *root, const char *student_id, const char *course_id);
void avl_clear(AVLNode *root);
int avl_traverse(AVLNode *root, VisitFn visit, void *ctx);

#endif
