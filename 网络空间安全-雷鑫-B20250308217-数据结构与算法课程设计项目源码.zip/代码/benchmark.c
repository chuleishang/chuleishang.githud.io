#include "benchmark.h"

#include "avl.h"
#include "generator.h"
#include "hash_table.h"
#include "list.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static size_t estimate_memory(int n, const char *type) {
    if (strcmp(type, "list") == 0) return sizeof(ListNode) * (size_t)n;
    if (strcmp(type, "avl") == 0) return sizeof(AVLNode) * (size_t)n;
    if (strcmp(type, "hash") == 0) return sizeof(HashNode) * (size_t)n + sizeof(HashNode *) * HASH_SIZE;
    return sizeof(Record) * (size_t)n;
}

static int count_visit(const Record *r, void *ctx) {
    int *count = (int *)ctx;
    (void)r;
    (*count)++;
    return 1;
}

static const char *cn_type(const char *type) {
    if (strcmp(type, "list") == 0) return "˫������";
    if (strcmp(type, "avl") == 0) return "AVL��";
    return "��ϣ��";
}

static void print_row(const char *op, const char *type, int n, double ms) {
    printf("%s,%s,%d,%.3f,%.3f\n", op, cn_type(type), n, ms, estimate_memory(n, type) / 1048576.0);
}

void benchmark(int n) {
    Record *data;
    Record *copy;
    LinkedList l;
    AVLNode *root = NULL;
    HashTable h;
    int i, ok = 0, traversed = 0;
    clock_t st, ed;

    if (n <= 0) {
        printf("���ݹ�ģ�������0��\n");
        return;
    }

    data = (Record *)malloc(sizeof(Record) * n);
    copy = (Record *)malloc(sizeof(Record) * n);
    if (!data || !copy) {
        printf("�ڴ����ʧ�ܣ��޷�ִ�����ܲ��ԡ�\n");
        free(data);
        free(copy);
        return;
    }

    for (i = 0; i < n; ++i) fill_generated_record(i, &data[i]);
    printf("����,���ݽṹ,���ݹ�ģ,��ʱms,�����ڴ�MB\n");

    list_init(&l);
    st = clock();
    for (i = 0; i < n; ++i) list_insert(&l, data[i]);
    ed = clock();
    print_row("����", "list", n, elapsed_ms(st, ed));
    st = clock(); list_find(&l, data[n / 2].student_id, data[n / 2].course_id); ed = clock();
    print_row("����", "list", n, elapsed_ms(st, ed));
    traversed = 0; st = clock(); list_traverse(&l, count_visit, &traversed); ed = clock();
    print_row("����", "list", n, elapsed_ms(st, ed));
    memcpy(copy, data, sizeof(Record) * n); st = clock(); qsort(copy, n, sizeof(Record), cmp_score_desc_id_asc); ed = clock();
    print_row("���ɼ�����", "list", n, elapsed_ms(st, ed));
    st = clock(); list_delete(&l, data[n / 3].student_id, data[n / 3].course_id); ed = clock();
    print_row("ɾ��", "list", n, elapsed_ms(st, ed));
    list_clear(&l);

    st = clock();
    for (i = 0; i < n; ++i) root = avl_insert_node(root, data[i], &ok);
    ed = clock();
    print_row("����", "avl", n, elapsed_ms(st, ed));
    st = clock(); avl_find(root, data[n / 2].student_id, data[n / 2].course_id); ed = clock();
    print_row("����", "avl", n, elapsed_ms(st, ed));
    traversed = 0; st = clock(); avl_traverse(root, count_visit, &traversed); ed = clock();
    print_row("����", "avl", n, elapsed_ms(st, ed));
    memcpy(copy, data, sizeof(Record) * n); st = clock(); qsort(copy, n, sizeof(Record), cmp_score_desc_id_asc); ed = clock();
    print_row("���ɼ�����", "avl", n, elapsed_ms(st, ed));
    st = clock(); root = avl_delete_node(root, data[n / 3].student_id, data[n / 3].course_id, &ok); ed = clock();
    print_row("ɾ��", "avl", n, elapsed_ms(st, ed));
    avl_clear(root);

    hash_init(&h);
    st = clock();
    for (i = 0; i < n; ++i) hash_insert(&h, data[i]);
    ed = clock();
    print_row("����", "hash", n, elapsed_ms(st, ed));
    st = clock(); hash_find(&h, data[n / 2].student_id, data[n / 2].course_id); ed = clock();
    print_row("����", "hash", n, elapsed_ms(st, ed));
    traversed = 0; st = clock(); hash_traverse(&h, count_visit, &traversed); ed = clock();
    print_row("����", "hash", n, elapsed_ms(st, ed));
    memcpy(copy, data, sizeof(Record) * n); st = clock(); qsort(copy, n, sizeof(Record), cmp_score_desc_id_asc); ed = clock();
    print_row("���ɼ�����", "hash", n, elapsed_ms(st, ed));
    st = clock(); hash_delete(&h, data[n / 3].student_id, data[n / 3].course_id); ed = clock();
    print_row("ɾ��", "hash", n, elapsed_ms(st, ed));
    hash_clear(&h);

    free(data);
    free(copy);
}
