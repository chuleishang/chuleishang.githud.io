#ifndef BENCHMARK_H
#define BENCHMARK_H

void benchmark(int n);

#endif
