#include "course_system.h"

#include "storage.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char key[COURSE_NAME_LEN];
    int count;
    double credit_sum;
} StatItem;

typedef struct {
    StatItem *items;
    int size;
    int capacity;
} StatList;

static void stat_list_init(StatList *list) {
    list->items = NULL;
    list->size = 0;
    list->capacity = 0;
}

static void stat_list_free(StatList *list) {
    free(list->items);
    list->items = NULL;
    list->size = 0;
    list->capacity = 0;
}

static int stat_list_find(StatList *list, const char *key) {
    int i;
    for (i = 0; i < list->size; ++i) {
        if (strcmp(list->items[i].key, key) == 0) return i;
    }
    return -1;
}

static int stat_list_add(StatList *list, const char *key) {
    int index = stat_list_find(list, key);
    StatItem *new_items;
    int new_capacity;

    if (index >= 0) return index;

    if (list->size == list->capacity) {
        new_capacity = list->capacity == 0 ? 16 : list->capacity * 2;
        new_items = (StatItem *)realloc(list->items, sizeof(StatItem) * new_capacity);
        if (!new_items) return -1;
        list->items = new_items;
        list->capacity = new_capacity;
    }

    index = list->size;
    list->size++;
    snprintf(list->items[index].key, sizeof(list->items[index].key), "%s", key);
    list->items[index].count = 0;
    list->items[index].credit_sum = 0.0;
    return index;
}

void system_init(CourseSystem *s) {
    list_init(&s->list);
    s->avl_root = NULL;
    hash_init(&s->hash);
    array_init(&s->records);
}

void system_clear(CourseSystem *s) {
    list_clear(&s->list);
    avl_clear(s->avl_root);
    s->avl_root = NULL;
    hash_clear(&s->hash);
    array_free(&s->records);
}

int system_insert(CourseSystem *s, Record rec) {
    int ok = 0;
    AVLNode *new_root;

    if (!valid_record(&rec)) return 0;
    if (array_find(&s->records, rec.student_id, rec.course_id)) return 0;
    if (!array_push(&s->records, rec)) return 0;

    if (!list_insert(&s->list, rec)) {
        array_remove_key(&s->records, rec.student_id, rec.course_id);
        return 0;
    }

    new_root = avl_insert_node(s->avl_root, rec, &ok);
    if (!ok) {
        array_remove_key(&s->records, rec.student_id, rec.course_id);
        list_delete(&s->list, rec.student_id, rec.course_id);
        return 0;
    }
    s->avl_root = new_root;

    if (!hash_insert(&s->hash, rec)) {
        system_delete(s, rec.student_id, rec.course_id);
        return 0;
    }

    return 1;
}

int system_delete(CourseSystem *s, const char *student_id, const char *course_id) {
    int deleted = 0;
    int a = array_remove_key(&s->records, student_id, course_id);
    int b = list_delete(&s->list, student_id, course_id);
    int h;
    s->avl_root = avl_delete_node(s->avl_root, student_id, course_id, &deleted);
    h = hash_delete(&s->hash, student_id, course_id);
    return a || b || deleted || h;
}

int system_modify_score(CourseSystem *s, const char *student_id, const char *course_id, int score) {
    int changed = 0;
    Record *r;

    if (score < 0 || score > 100) return 0;

    r = array_find(&s->records, student_id, course_id);
    if (r) { r->score = score; changed = 1; }

    r = list_find(&s->list, student_id, course_id);
    if (r) { r->score = score; changed = 1; }

    r = avl_find(s->avl_root, student_id, course_id);
    if (r) { r->score = score; changed = 1; }

    r = hash_find(&s->hash, student_id, course_id);
    if (r) { r->score = score; changed = 1; }

    return changed;
}

int system_load_csv(CourseSystem *s, const char *path) {
    FILE *fp = fopen(path, "r");
    char line[512];
    int count = 0;
    if (!fp) return 0;
    fgets(line, sizeof(line), fp);
    while (fgets(line, sizeof(line), fp)) {
        Record r;
        if (parse_csv_line(line, &r) && system_insert(s, r)) count++;
    }
    fclose(fp);
    return count;
}

int system_save_csv(CourseSystem *s, const char *path) {
    return save_csv(path, &s->records);
}

void system_statistics(CourseSystem *s) {
    StatList course, college, student, term;
    int grade[5] = {0};
    int i, idx, show_count;

    if (s->records.size == 0) {
        printf("��ǰû�м�¼��ͳ�ơ�\n");
        return;
    }

    stat_list_init(&course);
    stat_list_init(&college);
    stat_list_init(&student);
    stat_list_init(&term);

    for (i = 0; i < s->records.size; ++i) {
        Record *r = &s->records.items[i];

        idx = stat_list_add(&course, r->course_name);
        if (idx < 0) goto memory_error;
        course.items[idx].count++;

        idx = stat_list_add(&college, r->college);
        if (idx < 0) goto memory_error;
        college.items[idx].count++;

        idx = stat_list_add(&student, r->student_id);
        if (idx < 0) goto memory_error;
        student.items[idx].count++;
        student.items[idx].credit_sum += r->credit;

        idx = stat_list_add(&term, r->term);
        if (idx < 0) goto memory_error;
        term.items[idx].count++;

        if (r->score >= 90) grade[0]++;
        else if (r->score >= 80) grade[1]++;
        else if (r->score >= 70) grade[2]++;
        else if (r->score >= 60) grade[3]++;
        else grade[4]++;
    }

    printf("ÿ�ſγ�ѡ������������ʹ���ʣ�Ĭ������120����\n");
    for (i = 0; i < course.size; ++i) {
        printf("%s��%d�ˣ�ʹ���� %.2f%%\n",
               course.items[i].key, course.items[i].count, course.items[i].count * 100.0 / 120.0);
    }

    printf("\n��ѧԺѡ�������ֲ���\n");
    for (i = 0; i < college.size; ++i) {
        printf("%s��%d\n", college.items[i].key, college.items[i].count);
    }

    printf("\n��ѧ��ͳ��ѡ��������\n");
    for (i = 0; i < term.size; ++i) {
        printf("%s��%d\n", term.items[i].key, term.items[i].count);
    }

    printf("\nÿ��ѧ���ۼ�ѧ�֣�ֻ��ʾǰ20������\n");
    show_count = student.size < 20 ? student.size : 20;
    for (i = 0; i < show_count; ++i) {
        printf("%s��ѡ��%d�ţ��ۼ�ѧ�� %.1f\n",
               student.items[i].key, student.items[i].count, student.items[i].credit_sum);
    }

    printf("\n�ɼ��ֲ�������=%d ����=%d �е�=%d ����=%d ������=%d\n",
           grade[0], grade[1], grade[2], grade[3], grade[4]);

    stat_list_free(&course);
    stat_list_free(&college);
    stat_list_free(&student);
    stat_list_free(&term);
    return;

memory_error:
    printf("ͳ��ʱ�ڴ治�㣬�޷����ͳ�ơ�\n");
    stat_list_free(&course);
    stat_list_free(&college);
    stat_list_free(&student);
    stat_list_free(&term);
}

int system_delete_expired(CourseSystem *s, int confirm) {
    int i, count = 0;
    for (i = 0; i < s->records.size; ++i) {
        if (strcmp(s->records.items[i].date, "2023-09-01") < 0) count++;
    }
    printf("��⵽ %d ��ѡ���������� 2023-09-01 �Ĺ��ڼ�¼��\n", count);
    if (!confirm || count == 0) return 0;
    for (i = 0; i < s->records.size; ) {
        if (strcmp(s->records.items[i].date, "2023-09-01") < 0) {
            char sid[ID_LEN], cid[COURSE_ID_LEN];
            snprintf(sid, sizeof(sid), "%s", s->records.items[i].student_id);
            snprintf(cid, sizeof(cid), "%s", s->records.items[i].course_id);
            system_delete(s, sid, cid);
        } else {
            i++;
        }
    }
    return count;
}
