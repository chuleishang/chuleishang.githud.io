#ifndef COURSE_SYSTEM_H
#define COURSE_SYSTEM_H

#include "array_store.h"
#include "avl.h"
#include "hash_table.h"
#include "list.h"

typedef struct {
    LinkedList list;
    AVLNode *avl_root;
    HashTable hash;
    RecordArray records;
} CourseSystem;

void system_init(CourseSystem *s);
void system_clear(CourseSystem *s);
int system_insert(CourseSystem *s, Record rec);
int system_delete(CourseSystem *s, const char *student_id, const char *course_id);
int system_modify_score(CourseSystem *s, const char *student_id, const char *course_id, int score);
int system_load_csv(CourseSystem *s, const char *path);
int system_save_csv(CourseSystem *s, const char *path);
void system_statistics(CourseSystem *s);
int system_delete_expired(CourseSystem *s, int confirm);

#endif
