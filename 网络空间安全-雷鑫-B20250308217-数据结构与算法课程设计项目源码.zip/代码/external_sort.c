#include "external_sort.h"

#include "record.h"
#include "storage.h"

#include <stdio.h>
#include <stdlib.h>

int external_sort(const char *input, const char *output) {
    FILE *in = fopen(input, "r");
    FILE *out;
    char header[512];
    Record chunk[CHUNK_SIZE];
    char temp_names[256][64];
    int temp_count = 0;
    int total_reads = 0, total_writes = 0;
    int i, n;
    if (!in) {
        printf("�޷��������ļ���%s\n", input);
        return 0;
    }
    fgets(header, sizeof(header), in);
    while (1) {
        n = 0;
        while (n < CHUNK_SIZE && read_record_line(in, &chunk[n])) {
            n++;
            total_reads++;
        }
        if (n == 0) break;
        qsort(chunk, n, sizeof(Record), cmp_student_id);
        snprintf(temp_names[temp_count], sizeof(temp_names[temp_count]), "chunk_%03d.tmp", temp_count);
        out = fopen(temp_names[temp_count], "w");
        if (!out) {
            fclose(in);
            return 0;
        }
        for (i = 0; i < n; ++i) {
            fprintf(out, "%s,%s,%s,%s,%s,%.1f,%s,%s,%d\n",
                    chunk[i].student_id, chunk[i].name, chunk[i].college, chunk[i].course_id,
                    chunk[i].course_name, chunk[i].credit, chunk[i].term, chunk[i].date, chunk[i].score);
            total_writes++;
        }
        fclose(out);
        printf("�� %d ����ʼ�鲢�Σ���ȡ %d ����д�� %d ������ʱ�ļ� %s\n",
               temp_count + 1, n, n, temp_names[temp_count]);
        temp_count++;
        if (temp_count >= 256) break;
    }
    fclose(in);

    {
        FILE *fps[256];
        Record heads[256];
        int active[256];
        int active_count = 0;
        int round_reads = 0, round_writes = 0;
        for (i = 0; i < temp_count; ++i) {
            fps[i] = fopen(temp_names[i], "r");
            active[i] = fps[i] && read_record_line(fps[i], &heads[i]);
            if (active[i]) {
                active_count++;
                total_reads++;
                round_reads++;
            }
        }
        out = fopen(output, "w");
        if (!out) return 0;
        fprintf(out, "student_id,name,college,course_id,course_name,credit,term,date,score\n");
        while (active_count > 0) {
            int min_idx = -1;
            for (i = 0; i < temp_count; ++i) {
                if (active[i] && (min_idx < 0 || cmp_student_id(&heads[i], &heads[min_idx]) < 0)) min_idx = i;
            }
            fprintf(out, "%s,%s,%s,%s,%s,%.1f,%s,%s,%d\n",
                    heads[min_idx].student_id, heads[min_idx].name, heads[min_idx].college,
                    heads[min_idx].course_id, heads[min_idx].course_name, heads[min_idx].credit,
                    heads[min_idx].term, heads[min_idx].date, heads[min_idx].score);
            total_writes++;
            round_writes++;
            if (read_record_line(fps[min_idx], &heads[min_idx])) {
                total_reads++;
                round_reads++;
            } else {
                active[min_idx] = 0;
                active_count--;
            }
        }
        fclose(out);
        for (i = 0; i < temp_count; ++i) {
            if (fps[i]) fclose(fps[i]);
            remove(temp_names[i]);
        }
        printf("�鲢�ִ���Ϣ����ʱ�ļ���=%d�����ֶ�ȡ=%d������д��=%d\n", temp_count, round_reads, round_writes);
        printf("�ⲿ������ɣ��ܶ�ȡ=%d����д��=%d������ļ�=%s\n", total_reads, total_writes, output);
    }
    return 1;
}
