#ifndef EXTERNAL_SORT_H
#define EXTERNAL_SORT_H

int external_sort(const char *input, const char *output);

#endif
