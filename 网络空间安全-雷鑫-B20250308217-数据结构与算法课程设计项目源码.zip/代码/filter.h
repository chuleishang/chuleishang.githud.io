#ifndef FILTER_H
#define FILTER_H

#include <stdio.h>
#include "course_system.h"

typedef struct {
    const char *course_like;
    const char *term;
    const char *college;
    int min_score;
    int max_score;
    FILE *out;
    int count;
} FilterCtx;

int filter_visit(const Record *r, void *ctx);
void run_filter(CourseSystem *s);
void show_sorted_top(CourseSystem *s, int top_n);

#endif
