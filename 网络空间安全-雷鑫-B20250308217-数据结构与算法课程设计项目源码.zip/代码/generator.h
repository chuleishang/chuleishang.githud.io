#ifndef GENERATOR_H
#define GENERATOR_H

#include "record.h"

void fill_generated_record(int index, Record *r);
int generate_csv(const char *path, int n);

#endif
