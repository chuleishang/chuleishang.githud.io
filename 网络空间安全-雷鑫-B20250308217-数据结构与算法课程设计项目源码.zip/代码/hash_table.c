#include "hash_table.h"

#include <stdlib.h>
#include <string.h>

void hash_init(HashTable *h) {
    h->buckets = (HashNode **)calloc(HASH_SIZE, sizeof(HashNode *));
    h->size = 0;
}

void hash_clear(HashTable *h) {
    int i;
    if (!h->buckets) return;
    for (i = 0; i < HASH_SIZE; ++i) {
        HashNode *p = h->buckets[i];
        while (p) {
            HashNode *next = p->next;
            free(p);
            p = next;
        }
    }
    free(h->buckets);
    h->buckets = NULL;
    h->size = 0;
}

int hash_insert(HashTable *h, Record rec) {
    unsigned long idx = hash_key(rec.student_id, rec.course_id);
    HashNode *p;
    if (!h->buckets) return 0;
    p = h->buckets[idx];
    while (p) {
        if (strcmp(p->data.student_id, rec.student_id) == 0 &&
            strcmp(p->data.course_id, rec.course_id) == 0) {
            p->data = rec;
            return 1;
        }
        p = p->next;
    }
    p = (HashNode *)malloc(sizeof(HashNode));
    if (!p) return 0;
    p->data = rec;
    p->next = h->buckets[idx];
    h->buckets[idx] = p;
    h->size++;
    return 1;
}

Record *hash_find(HashTable *h, const char *student_id, const char *course_id) {
    unsigned long idx = hash_key(student_id, course_id);
    HashNode *p;
    if (!h->buckets) return NULL;
    p = h->buckets[idx];
    while (p) {
        if (strcmp(p->data.student_id, student_id) == 0 &&
            strcmp(p->data.course_id, course_id) == 0) return &p->data;
        p = p->next;
    }
    return NULL;
}

int hash_delete(HashTable *h, const char *student_id, const char *course_id) {
    unsigned long idx = hash_key(student_id, course_id);
    HashNode *p, *prev = NULL;
    if (!h->buckets) return 0;
    p = h->buckets[idx];
    while (p) {
        if (strcmp(p->data.student_id, student_id) == 0 &&
            strcmp(p->data.course_id, course_id) == 0) {
            if (prev) prev->next = p->next;
            else h->buckets[idx] = p->next;
            free(p);
            h->size--;
            return 1;
        }
        prev = p;
        p = p->next;
    }
    return 0;
}

int hash_traverse(HashTable *h, VisitFn visit, void *ctx) {
    int i;
    if (!h->buckets) return 0;
    for (i = 0; i < HASH_SIZE; ++i) {
        HashNode *p = h->buckets[i];
        while (p) {
            if (!visit(&p->data, ctx)) return 0;
            p = p->next;
        }
    }
    return 1;
}
