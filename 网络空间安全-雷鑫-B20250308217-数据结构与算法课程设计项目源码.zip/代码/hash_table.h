#ifndef HASH_TABLE_H
#define HASH_TABLE_H

#include "record.h"

typedef struct HashNode {
    Record data;
    struct HashNode *next;
} HashNode;

typedef struct {
    HashNode **buckets;
    int size;
} HashTable;

void hash_init(HashTable *h);
void hash_clear(HashTable *h);
int hash_insert(HashTable *h, Record rec);
Record *hash_find(HashTable *h, const char *student_id, const char *course_id);
int hash_delete(HashTable *h, const char *student_id, const char *course_id);
int hash_traverse(HashTable *h, VisitFn visit, void *ctx);

#endif
