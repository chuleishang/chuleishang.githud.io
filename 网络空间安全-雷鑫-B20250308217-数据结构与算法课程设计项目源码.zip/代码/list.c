#include "list.h"

#include <stdlib.h>
#include <string.h>

void list_init(LinkedList *l) {
    l->head = l->tail = NULL;
    l->size = 0;
}

void list_clear(LinkedList *l) {
    ListNode *p = l->head;
    while (p) {
        ListNode *next = p->next;
        free(p);
        p = next;
    }
    list_init(l);
}

int list_insert(LinkedList *l, Record rec) {
    ListNode *node = (ListNode *)malloc(sizeof(ListNode));
    if (!node) return 0;
    node->data = rec;
    node->prev = l->tail;
    node->next = NULL;
    if (l->tail) l->tail->next = node;
    else l->head = node;
    l->tail = node;
    l->size++;
    return 1;
}

Record *list_find(LinkedList *l, const char *student_id, const char *course_id) {
    ListNode *p;
    for (p = l->head; p; p = p->next) {
        if (strcmp(p->data.student_id, student_id) == 0 &&
            strcmp(p->data.course_id, course_id) == 0) return &p->data;
    }
    return NULL;
}

int list_delete(LinkedList *l, const char *student_id, const char *course_id) {
    ListNode *p;
    for (p = l->head; p; p = p->next) {
        if (strcmp(p->data.student_id, student_id) == 0 &&
            strcmp(p->data.course_id, course_id) == 0) {
            if (p->prev) p->prev->next = p->next;
            else l->head = p->next;
            if (p->next) p->next->prev = p->prev;
            else l->tail = p->prev;
            free(p);
            l->size--;
            return 1;
        }
    }
    return 0;
}

int list_traverse(LinkedList *l, VisitFn visit, void *ctx) {
    ListNode *p;
    for (p = l->head; p; p = p->next) {
        if (!visit(&p->data, ctx)) return 0;
    }
    return 1;
}
