#ifndef LIST_H
#define LIST_H

#include "record.h"

typedef struct ListNode {
    Record data;
    struct ListNode *prev;
    struct ListNode *next;
} ListNode;

typedef struct {
    ListNode *head;
    ListNode *tail;
    int size;
} LinkedList;

void list_init(LinkedList *l);
void list_clear(LinkedList *l);
int list_insert(LinkedList *l, Record rec);
Record *list_find(LinkedList *l, const char *student_id, const char *course_id);
int list_delete(LinkedList *l, const char *student_id, const char *course_id);
int list_traverse(LinkedList *l, VisitFn visit, void *ctx);

#endif
