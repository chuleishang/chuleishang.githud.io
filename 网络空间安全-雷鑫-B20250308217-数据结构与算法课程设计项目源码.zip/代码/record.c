#include "record.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

int record_key_cmp(const Record *a, const Record *b) {
    int c = strcmp(a->student_id, b->student_id);
    if (c != 0) return c;
    return strcmp(a->course_id, b->course_id);
}

int key_cmp(const char *student_id, const char *course_id, const Record *b) {
    int c = strcmp(student_id, b->student_id);
    if (c != 0) return c;
    return strcmp(course_id, b->course_id);
}

unsigned long hash_key(const char *student_id, const char *course_id) {
    unsigned long h = 5381;
    const unsigned char *p;
    for (p = (const unsigned char *)student_id; *p; ++p) h = ((h << 5) + h) + *p;
    h = ((h << 5) + h) + '#';
    for (p = (const unsigned char *)course_id; *p; ++p) h = ((h << 5) + h) + *p;
    return h % HASH_SIZE;
}

static int is_digits_part(const char *s, int start, int len) {
    int i;
    for (i = 0; i < len; ++i) {
        if (!isdigit((unsigned char)s[start + i])) return 0;
    }
    return 1;
}

static int is_digits(const char *s, int len) {
    return (int)strlen(s) == len && is_digits_part(s, 0, len);
}

static int valid_term(const char *term) {
    int no;
    if (strlen(term) != 7) return 0;
    if (!is_digits_part(term, 0, 4) || term[4] != '-' || !is_digits_part(term, 5, 2)) return 0;
    no = (term[5] - '0') * 10 + (term[6] - '0');
    return no == 1 || no == 2;
}

static int valid_date(const char *date) {
    int month, day;
    if (strlen(date) != 10) return 0;
    if (!is_digits_part(date, 0, 4) || date[4] != '-' ||
        !is_digits_part(date, 5, 2) || date[7] != '-' ||
        !is_digits_part(date, 8, 2)) {
        return 0;
    }
    month = (date[5] - '0') * 10 + (date[6] - '0');
    day = (date[8] - '0') * 10 + (date[9] - '0');
    return month >= 1 && month <= 12 && day >= 1 && day <= 31;
}

int valid_record(const Record *r) {
    return r->name[0] != '\0' &&
           r->college[0] != '\0' &&
           r->course_name[0] != '\0' &&
           is_digits(r->student_id, 12) &&
           strlen(r->course_id) == 8 &&
           valid_term(r->term) &&
           valid_date(r->date) &&
           r->score >= 0 && r->score <= 100 &&
           r->credit > 0.0 && r->credit <= 10.0;
}

void print_record(const Record *r) {
    printf("%s,%s,%s,%s,%s,%.1f,%s,%s,%d\n",
           r->student_id, r->name, r->college, r->course_id, r->course_name,
           r->credit, r->term, r->date, r->score);
}

int cmp_score_desc_id_asc(const void *pa, const void *pb) {
    const Record *a = (const Record *)pa;
    const Record *b = (const Record *)pb;
    if (a->score != b->score) return b->score - a->score;
    return strcmp(a->student_id, b->student_id);
}

int cmp_student_id(const void *pa, const void *pb) {
    const Record *a = (const Record *)pa;
    const Record *b = (const Record *)pb;
    int c = strcmp(a->student_id, b->student_id);
    if (c != 0) return c;
    return strcmp(a->course_id, b->course_id);
}

double elapsed_ms(clock_t start, clock_t end) {
    return (double)(end - start) * 1000.0 / CLOCKS_PER_SEC;
}
