#ifndef RECORD_H
#define RECORD_H

#include <stddef.h>
#include <time.h>

#define ID_LEN 13
#define NAME_LEN 32
#define COLLEGE_LEN 64
#define COURSE_ID_LEN 9
#define COURSE_NAME_LEN 64
#define TERM_LEN 8
#define DATE_LEN 11
#define HASH_SIZE 200003
#define CHUNK_SIZE 1000

typedef struct {
    char student_id[ID_LEN];
    char name[NAME_LEN];
    char college[COLLEGE_LEN];
    char course_id[COURSE_ID_LEN];
    char course_name[COURSE_NAME_LEN];
    double credit;
    char term[TERM_LEN];
    char date[DATE_LEN];
    int score;
} Record;

typedef int (*VisitFn)(const Record *rec, void *ctx);

int record_key_cmp(const Record *a, const Record *b);
int key_cmp(const char *student_id, const char *course_id, const Record *b);
unsigned long hash_key(const char *student_id, const char *course_id);
int valid_record(const Record *r);
void print_record(const Record *r);
int cmp_score_desc_id_asc(const void *pa, const void *pb);
int cmp_student_id(const void *pa, const void *pb);
double elapsed_ms(clock_t start, clock_t end);

#endif
