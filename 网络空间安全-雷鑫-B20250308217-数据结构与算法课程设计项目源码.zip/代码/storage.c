#include "storage.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int parse_csv_line(char *line, Record *r) {
    char *fields[9];
    int i = 0;
    char *p = strtok(line, ",\r\n");
    while (p && i < 9) {
        fields[i++] = p;
        p = strtok(NULL, ",\r\n");
    }
    if (i != 9) return 0;
    snprintf(r->student_id, sizeof(r->student_id), "%s", fields[0]);
    snprintf(r->name, sizeof(r->name), "%s", fields[1]);
    snprintf(r->college, sizeof(r->college), "%s", fields[2]);
    snprintf(r->course_id, sizeof(r->course_id), "%s", fields[3]);
    snprintf(r->course_name, sizeof(r->course_name), "%s", fields[4]);
    r->credit = atof(fields[5]);
    snprintf(r->term, sizeof(r->term), "%s", fields[6]);
    snprintf(r->date, sizeof(r->date), "%s", fields[7]);
    r->score = atoi(fields[8]);
    return 1;
}

int read_record_line(FILE *fp, Record *r) {
    char line[512];
    if (!fgets(line, sizeof(line), fp)) return 0;
    return parse_csv_line(line, r);
}

int save_csv(const char *path, const RecordArray *a) {
    FILE *fp = fopen(path, "w");
    int i;
    if (!fp) return 0;
    fprintf(fp, "student_id,name,college,course_id,course_name,credit,term,date,score\n");
    for (i = 0; i < a->size; ++i) {
        const Record *r = &a->items[i];
        fprintf(fp, "%s,%s,%s,%s,%s,%.1f,%s,%s,%d\n",
                r->student_id, r->name, r->college, r->course_id, r->course_name,
                r->credit, r->term, r->date, r->score);
    }
    fclose(fp);
    return 1;
}
