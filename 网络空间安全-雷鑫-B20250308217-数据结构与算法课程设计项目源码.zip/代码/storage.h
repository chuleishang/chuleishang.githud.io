#ifndef STORAGE_H
#define STORAGE_H

#include <stdio.h>
#include "array_store.h"

int parse_csv_line(char *line, Record *r);
int read_record_line(FILE *fp, Record *r);
int save_csv(const char *path, const RecordArray *a);

#endif
